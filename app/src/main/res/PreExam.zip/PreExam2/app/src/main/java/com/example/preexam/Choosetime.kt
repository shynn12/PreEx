package com.example.preexam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Choosetime : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choosetime)
    }
}